"""Independent, reproducible audit of a retrospective SOFR cash sensitivity.

Run: python validate_cash_overlay.py
Only standard library is required. Inputs in this directory are frozen extracts.
No engine rerun, remote mutation, trading optimization or investment access implied.
"""
from pathlib import Path
from datetime import date, timedelta
from decimal import Decimal as D, localcontext
from hashlib import sha1, sha256
from statistics import mean, stdev
import csv
import json

ROOT = Path(__file__).resolve().parent
COMMIT = '8b395342b7e3a9dd1fbb59f72bee6b5e6efebb49'
REPO = 'pgs00/crypto-carry-thesis-pablo-salerno'
START, END = date(2022, 1, 1), date(2026, 9, 1)
N = (END - START).days
DATES = [str(START + timedelta(days=i)) for i in range(N)]
SOURCES = {
 'frozen_daily_cash_full.csv': ('results/benchmark_sofr/evidencia/reutilizado/diario_reutilizado.csv', '6d98ac6f1a8b31a84ed5f3d64d887fd73aea2d12'),
 'frozen_sofr_daily.csv': ('results/benchmark_sofr/evidencia/tablas/cartera_sofr_diaria.csv', '3f8a4ca6d8cbece5feeb88bce5000cf029047161'),
 'frozen_h3_daily.csv': ('results/base/continuo/tablas/h3_diario_conjunto.csv', '9ee33fbec1b536a84fef1eb1e66420b1780c7cf7'),
 'frozen_sofr_sources.json': ('results/benchmark_sofr/evidencia/fuentes_publicas/fuentes.json', 'cf20820d86872b4b37a3a0d4f5dcc3b459313344'),
 'frozen_sofr_rates.json': ('results/benchmark_sofr/evidencia/fuentes_publicas/sofr_serie.json', '538f91f9d8ad190a0e52addcebd265ec3e432574'),
 'frozen_sofr_calendar.csv': ('results/benchmark_sofr/evidencia/tablas/calendario_verificado.csv', '9592277cfffc8545980b44b4924e23424b02b335'),
}

def read(name):
    with (ROOT / name).open(newline='') as f:
        return list(csv.DictReader(f))

def write_csv(name, rows):
    with (ROOT / name).open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)

def json_write(name, obj):
    (ROOT / name).write_text(json.dumps(obj, indent=2, default=str, ensure_ascii=False) + '\n')

def near(a, b, tol=D('1e-18')):
    assert abs(D(a) - D(b)) < tol, (a, b, D(a) - D(b))

def metrics(equities, opening):
    daily = []
    previous = opening
    peak, min_dd = opening, D(0)
    for equity in equities:
        daily.append(float(equity / previous - 1))
        peak = max(peak, equity)
        min_dd = min(min_dd, equity / peak - 1)
        previous = equity
    sigma = stdev(daily)
    return {
      'starting_equity': opening, 'final_equity': equities[-1],
      'return_percent': (equities[-1] / opening - 1) * 100,
      'CAGR365_percent': ((equities[-1] / opening) ** (D(365) / len(equities)) - 1) * 100,
      'Sharpe_rf0': mean(daily) / sigma * 365 ** .5 if sigma else None,
      'volatility365_percent': sigma * 365 ** .5 * 100,
      'max_drawdown_daily_percent': min_dd * 100,
    }

def audit_sources():
    provenance = []
    for name, (path, expected) in SOURCES.items():
        b = (ROOT / name).read_bytes()
        actual = sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
        assert actual == expected, (name, actual)
        provenance.append(dict(local_file=name, repository_path=path, commit=COMMIT,
            git_blob_sha1=actual, sha256=sha256(b).hexdigest(), bytes=len(b),
            url=f'https://github.com/{REPO}/blob/{COMMIT}/{path}'))
    full, compact = read('frozen_daily_cash_full.csv'), read('daily_cash.csv')
    full_map = {(r['strategy'], r['date']): r for r in full}
    assert len(full_map) == len(compact) == 2 * N
    for row in compact:
        source = full_map[row['strategy'], row['date']]
        assert source['scenario'] == 'BASE_E3' and source['partial_day'] == 'False'
        for key, value in row.items():
            assert value == source[key], (key, row['date'])
        near(source['reconciliation_residual_usdt'], 0)
        near(source['balance_residual_usdt'], 0)
        assert D(source['debt_usdt']) == 0
        assert D(source['free_cash_usdt']) >= 0
    rates = read('frozen_sofr_daily.csv')
    rate_map = {r['date']: r for r in rates}
    assert list(rate_map) == DATES
    for row in read('sofr_daily.csv'):
        assert all(value == rate_map[row['date']][key] for key, value in row.items())
    assert read('h3_daily.csv') == read('frozen_h3_daily.csv')
    official = {r['effectiveDate']: r for r in json.loads((ROOT / 'frozen_sofr_rates.json').read_text(), parse_float=D)['refRates']}
    calendar = {r['date']: r for r in read('frozen_sofr_calendar.csv')}
    for row in rates:
        day = date.fromisoformat(row['date'])
        effective = row['rate_effective_date']
        published = row['rate_publication_date_expected']
        assert D(row['annual_decimal_rate']) == D(official[effective]['percentRate']) / 100
        assert calendar[effective]['is_business_day'] == 'True'
        assert calendar[published]['is_business_day'] == 'True'
        assert row['capitalized_at_close'] == str(str(day + timedelta(days=1)) == published)
        assert effective <= row['date'] < published
        assert row['carry_close_time_ns'] == str(int(full_map['conditional', row['date']]['time_ns']))
    expected_rate_hash = next(r['sha256'] for r in json.loads((ROOT / 'frozen_sofr_sources.json').read_text()) if r['file'] == 'sofr_serie.json')
    assert sha256((ROOT / 'frozen_sofr_rates.json').read_bytes()).hexdigest() == expected_rate_hash
    return full, rates, provenance

def build_path(rows, rates, fraction=D(1), reinvest=True):
    """Business-block implementation, independently differs from prior daily loop.

    Base cash is rebalanced notionally daily; realized SOFR accrual is recorded
    retrospectively. Interest earned during a block is not reinvested until its
    end. Base trades and equity remain unchanged, including across year ends.
    """
    rows = sorted(rows, key=lambda r: r['date'])
    assert [r['date'] for r in rows] == DATES
    original_cash = [D(10000)] + [max(D(r['free_cash_usdt'])-D(r['debt_usdt']), D(0)) for r in rows[:-1]]
    cumulative_interest = D(0)
    path = []
    i = 0
    while i < len(rows):
        block_id = rates[i]['block_id']
        j = i + 1
        while j < len(rows) and rates[j]['block_id'] == block_id:
            j += 1
        at_block_start = cumulative_interest if reinvest else D(0)
        pending = D(0)
        for k in range(i, j):
            base_cash = original_cash[k] * fraction
            interest = (base_cash + at_block_start) * D(rates[k]['annual_decimal_rate']) / 360
            pending += interest
            total_interest = cumulative_interest + pending
            base_equity = D(rows[k]['equity_usdt'])
            path.append(dict(date=rows[k]['date'], strategy=rows[k]['strategy'], cash_fraction=fraction,
                base_equity_usdt=base_equity, lagged_book_cash_usdt=original_cash[k],
                remunerated_base_cash_usdt=base_cash, annual_decimal_rate=D(rates[k]['annual_decimal_rate']),
                prior_capitalized_interest_usdt=at_block_start,
                incremental_interest_usdt=interest, cumulative_interest_usdt=total_interest,
                adjusted_equity_usdt=base_equity + total_interest,
                capitalized_at_close=rates[k]['capitalized_at_close']))
        cumulative_interest += pending
        i = j
    return path

def period_summary(path, label, low, high):
    selected = [r for r in path if low <= r['date'] < high]
    first_index = path.index(selected[0])
    prev = path[first_index-1] if first_index else None
    opening = prev['adjusted_equity_usdt'] if prev else D(10000)
    opening_base = prev['base_equity_usdt'] if prev else D(10000)
    opening_interest = prev['cumulative_interest_usdt'] if prev else D(0)
    m = metrics([r['adjusted_equity_usdt'] for r in selected], opening)
    bm = metrics([r['base_equity_usdt'] for r in selected], opening_base)
    return dict(period=label, start=low, end_exclusive=high, days=len(selected),
        strategy=path[0]['strategy'], cash_fraction=path[0]['cash_fraction'],
        incremental_interest_usdt=selected[-1]['cumulative_interest_usdt']-opening_interest,
        cumulative_interest_usdt=selected[-1]['cumulative_interest_usdt'],
        **m, **{'base_'+k:v for k,v in bm.items()})

def run():
    with localcontext() as ctx:
        ctx.prec = 50
        full, rates, provenance = audit_sources()
        # Independent constant-cash control against all 1,704 source closes.
        dummy = [dict(r, strategy='idle', free_cash_usdt='10000', debt_usdt='0', equity_usdt='10000') for r in full if r['strategy']=='conditional']
        idle = build_path(dummy, rates)
        for p, r in zip(idle, rates):
            near(p['adjusted_equity_usdt'], r['balance_close'], D('1e-40'))
        paths, period_rows, cash_stats = {}, [], []
        periods = [(str(y), f'{y}-01-01', min(f'{y+1}-01-01', str(END))) for y in range(2022,2027)]
        periods += [('2022-2023','2022-01-01','2024-01-01'), ('2024-Aug2026','2024-01-01',str(END)), ('FULL',str(START),str(END))]
        for strategy in ('conditional', 'permanent'):
            rows = [r for r in full if r['strategy']==strategy]
            near(rows[-1]['equity_usdt'], {'conditional':'10785.7630496471659369','permanent':'11680.06921675742584680269999'}[strategy])
            for fraction in (D(0), D('.5'), D('.75'), D(1)):
                path = build_path(rows, rates, fraction)
                paths[strategy, fraction] = path
                period_rows += [period_summary(path,*p) for p in periods]
            nc = build_path(rows, rates, reinvest=False)
            period_rows += [dict(period_summary(nc, 'FULL_NO_REINVEST', str(START), str(END)), cash_fraction=D(1))]
            for label, low, high in periods:
                sel = [r for r in rows if low <= r['date'] < high]
                cash_stats.append(dict(period=label,strategy=strategy,days=len(sel),
                    mean_book_cash_to_equity_percent=mean(D(r['free_cash_usdt'])/D(r['equity_usdt']) for r in sel)*100,
                    mean_one_minus_utilization_percent=mean(1-D(r['capital_deployed_usdt'])/D(r['equity_usdt']) for r in sel)*100,
                    debt_days=sum(D(r['debt_usdt'])>0 for r in sel)))
        c, p = paths['conditional',D(1)][-1], paths['permanent',D(1)][-1]
        break_even = (p['base_equity_usdt']-c['base_equity_usdt'])/(c['cumulative_interest_usdt']-p['cumulative_interest_usdt'])
        # Exact linearity in availability fraction follows from this recurrence.
        for strategy in ('conditional','permanent'):
            for q in (D('.5'),D('.75')):
                for a,b in zip(paths[strategy,q],paths[strategy,D(1)]):
                    near(a['cumulative_interest_usdt'], q*b['cumulative_interest_usdt'],D('1e-40'))
        h3=[]
        for label, low, high in periods:
            rows=[r for r in read('frozen_h3_daily.csv') if low<=r['date']<high]
            valid=[r for r in rows if r['complete']=='True']
            h3.append(dict(period=label, days=len(rows),valid_days=len(valid),excluded_days=len(rows)-len(valid),
                opportunity_bps_per_168h=mean(D(r['opportunity']) for r in valid)*10000,
                eligible_minutes_percent=mean(D(r['eligible_fraction']) for r in valid)*100,
                days_with_positive_opportunity=sum(D(r['opportunity'])>0 for r in valid)))
        compare_rows=[]
        for q in (D(0),D('.5'),D('.75'),D(1)):
            c=next(r for r in period_rows if r['period']=='FULL' and r['strategy']=='conditional' and r['cash_fraction']==q)
            p=next(r for r in period_rows if r['period']=='FULL' and r['strategy']=='permanent' and r['cash_fraction']==q)
            compare_rows.append(dict(cash_fraction=q,
                conditional_final=c['final_equity'], permanent_final=p['final_equity'],
                conditional_CAGR365_percent=c['CAGR365_percent'],permanent_CAGR365_percent=p['CAGR365_percent'],
                conditional_Sharpe_rf0=c['Sharpe_rf0'],permanent_Sharpe_rf0=p['Sharpe_rf0'],
                conditional_interest=c['incremental_interest_usdt'],permanent_interest=p['incremental_interest_usdt'],
                exploratory_H2_numerical_criterion=c['CAGR365_percent']>0 and c['Sharpe_rf0']>p['Sharpe_rf0']))
        daily=[r for s in ('conditional','permanent') for r in paths[s,D(1)]]
        write_csv('daily_adjusted_equity.csv',daily)
        write_csv('annual_and_period_results.csv',period_rows)
        write_csv('availability_sensitivity.csv',compare_rows)
        write_csv('h3_annual_and_period.csv',h3)
        write_csv('cash_proxy_statistics.csv',cash_stats)
        json_write('source_provenance.json',dict(repository=REPO,commit=COMMIT,
            retrieval_method='Read-only GitHub connector at frozen commit; large daily file by Git blob endpoint',
            sources=provenance,
            input_extraction_checks='All compact fields reconcile exactly to the frozen full files',
            authoritative_methodology_url='https://www.newyorkfed.org/markets/reference-rates/additional-information-about-reference-rates'))
        results=dict(checks=dict(days=N, exact_compact_source_matches=True, source_git_blob_hashes=True,
            rate_and_calendar_checks=True, zero_debt_all_strategy_days=True,
            all_idle_closes_reproduce_benchmark=True, fractional_cash_linearity=True),
            controls=dict(idle_benchmark_final=idle[-1]['adjusted_equity_usdt'],
                terminal_wealth_ranking_break_even_cash_fraction=break_even,
                warning='Break-even is descriptive under common constant cash eligibility, not an optimized strategy'),
            availability_sensitivity=compare_rows,h3=h3,cash_proxy_statistics=cash_stats)
        json_write('independent_results.json',results)
        print(json.dumps(results,default=str,indent=2))

if __name__=='__main__':
    run()
