# Ampliación cuantitativa del feedback

Fuente: `pgs00/crypto-carry-thesis-pablo-salerno`, commit `8b395342b7e3a9dd1fbb59f72bee6b5e6efebb49`. Los tres insumos se verifican contra sus SHA de objetos Git y contra el archivo original E3. No se modificó ni volvió a ejecutar el backtest de las carteras.

## H1: referencias adicionales

Se mantiene exactamente la muestra original: 10.180 observaciones válidas; 42 exclusiones por final de muestra y 2 por límite no verificado del calendario. Se conserva el horizonte de 168 horas y el mismo funding futuro realizado. El MAE agregado da igual peso al MAE de BTC y ETH.

Las medias móviles de 7 y 14 días asignan igual peso a las observaciones históricas y normalizan por la suma de sus duraciones reales: `pronóstico = 168 × Σ funding / Σ horas`. Se usa la misma convención temporal del EWMA: `ancla − ventana < liquidación ≤ ancla`, con antecedente verificado, continuidad de intervalos y disponibilidad de todos los datos antes de la señal. No se impone una cantidad futura de liquidaciones. La constante de 0,01% cada 8 horas implica 21 pb en 168 horas.

| Período | N | EWMA | Sin cambio | Media 7 días | Media 14 días | Constante |
|---|---:|---:|---:|---:|---:|---:|
| Muestra completa | 10.180 | 6,2990 | 8,7033 | 6,5764 | 7,0443 | 13,1949 |
| 2022–2023 | 4.380 | 7,3842 | 10,2765 | 7,3668 | 7,4922 | 13,1744 |
| 2024–ago. 2026 | 5.800 | 5,4794 | 7,5153 | 5,9795 | 6,7061 | 13,2103 |
| 2022 | 2.190 | 9,1615 | 13,0861 | 9,0424 | 9,1471 | 16,3016 |
| 2023 | 2.190 | 5,6069 | 7,4668 | 5,6911 | 5,8373 | 10,0473 |
| 2024 | 2.196 | 7,5288 | 9,1529 | 8,7927 | 10,4292 | 12,3712 |
| 2025 | 2.190 | 4,1080 | 6,2726 | 4,1688 | 4,2024 | 11,4427 |
| Ene.–ago. 2026 | 1.414 | 4,4207 | 6,8969 | 4,4150 | 4,8019 | 17,2512 |

MAE en pb por 168 horas. Los grupos por año corresponden a la fecha de la señal; los últimos horizontes excluidos reducen el N de 2026. Las diferencias se calculan con precisión completa antes de redondear.

En la muestra completa, la reducción relativa del MAE del EWMA es 27,63% frente a sin cambio, 4,22% frente a la media de 7 días, 10,58% frente a la de 14 días y 52,26% frente a la constante. La fórmula es `100 × (1 − MAE_EWMA / MAE_referencia)`.

El contraste adicional matiza H1: la ventaja agregada del EWMA frente a una media móvil es menor que frente a sin cambio. La media de 7 días supera levemente al EWMA en 2022–2023, en 2022 y en enero–agosto de 2026; la de 14 días también lo supera levemente en 2022. Por tanto, los resultados no permiten afirmar que el EWMA sea superior a toda referencia en cada período. Estas comparaciones añadidas son descriptivas; los horizontes se superponen y no se calculó nueva significación estadística. Los intervalos bootstrap previos se refieren exclusivamente al contraste original EWMA versus sin cambio.

La constante de 21 pb no supera el umbral de selección de 34 pb: bajo ese filtro, por sí sola nunca habilitaría una entrada. Este dato no es el resultado de una simulación adicional de cartera.

## Basis observado

Se calcula a partir de los precios efectivos del archivo original de señales, como `10.000 × (precio futuro / precio spot − 1)`. Se consideran los momentos de señal de la estrategia condicional, incluso cuando el funding no supera el umbral o la cuenta no abre una posición. Las estadísticas no describen todos los minutos del mercado ni sólo las operaciones ejecutadas.

| Período | Evaluables | Media (pb) | Mediana (pb) | Basis negativo |
|---|---:|---:|---:|---:|
| Muestra completa | 10.223 | −3,1346 | −4,2937 | 86,57% |
| 2022–2023 | 4.379 | −3,4317 | −4,2775 | 88,26% |
| 2024–ago. 2026 | 5.844 | −2,9119 | −4,3007 | 85,30% |
| 2022 | 2.190 | −4,5856 | −4,6287 | 98,08% |
| 2023 | 2.189 | −2,2774 | −3,9007 | 78,44% |
| 2024 | 2.196 | −0,2367 | −2,8939 | 62,02% |
| 2025 | 2.190 | −4,3462 | −4,4704 | 99,09% |
| Ene.–ago. 2026 | 1.458 | −4,7870 | −4,8040 | 99,66% |

Son medias y medianas del conjunto de observaciones de BTC y ETH; no son promedios de las medianas por activo. El CSV incluye también los resultados separados por activo.

La mayor parte de los precios observados presenta un basis pequeño y negativo. El piso de cero excluye, por tanto, muchas señales aun cuando la magnitud de la diferencia es de pocos puntos básicos. Esto describe la muestra; no prueba que el piso sea económicamente óptimo ni evalúa una estrategia alternativa con basis negativo permitido.

**Precisión necesaria en el texto existente:** la única observación no evaluable es BTC del 10/11/2023 a las 16:01 UTC, con `filter_data_valid=fail`. El archivo conserva un cociente bruto de precios (6,1301 pb), pero no un basis validado para el filtro. Conviene escribir «En una evaluación de BTC, el filtro de basis se registra como no evaluable por invalidación de datos de mercado; esa observación se excluye de las estadísticas del basis evaluable», en lugar de afirmar que no se pudo calcular ningún cociente de precios o que fue la primera señal de la muestra.

## Funding de mercado por año

Tasa anualizada simple: `100 × 8.760 × Σ tasa de funding / Σ horas efectivas`, usando las tasas e intervalos verificados de las liquidaciones del año. No presupone tres liquidaciones diarias ni capitalización. La atribución al año usa la fecha de liquidación; el primer intervalo puede comenzar en el año previo.

| Año | BTC: funding anualizado | ETH: funding anualizado |
|---|---:|---:|
| 2022 | 4,1649% | 0,7873% |
| 2023 | 7,8657% | 8,2595% |
| 2024 | 11,9242% | 12,9614% |
| 2025 | 5,1264% | 4,9287% |
| Ene.–ago. 2026 | 2,6178% | 1,5679% |

Estas cifras contextualizan el entorno del carry: 2024 presenta tasas superiores a 2025 y enero–agosto de 2026. Son descriptores de las tasas de mercado, no retornos obtenibles sobre el patrimonio. No descuentan comisiones, diferencias de precio entre spot y futuro, margen, capital ocioso ni fallas operativas. La anualización de 2026 extrapola la media de una muestra parcial y no predice el cierre del año.

## Reproducción y archivos

Ejecutar `python analyze_feedback.py` desde cualquier directorio. Si faltan insumos, ejecutar `python analyze_feedback.py --download`. Sólo requiere la biblioteca estándar de Python. El programa exige coincidencia con los SHA Git publicados; reproduce exactamente cada pronóstico EWMA válido, reconcilia los MAE originales y verifica cada cociente bruto del basis contra los precios fuente.

- `outputs/h1_mae_summary.csv`: MAE general, por subperíodo, por año y por activo.
- `outputs/h1_relative_improvement.csv`: reducción relativa y diferencia absoluta respecto de cada referencia.
- `outputs/h1_paired_observations.csv`: 10.180 observaciones comunes, pronósticos y errores.
- `outputs/basis_summary.csv`: media, mediana, extremos, observaciones y proporción negativa.
- `outputs/basis_signal_observations.csv`: señales, precios y estados originales de validación.
- `outputs/funding_by_year.csv`: funding agregado, duración, tasa normalizada y anualización.
- `outputs/audit_and_provenance.json`: procedencia, hashes, fórmulas y limitaciones.

El contraste contra el repositorio congelado acredita consistencia con la evidencia publicada; no autentica de manera independiente los datos históricos del exchange.
