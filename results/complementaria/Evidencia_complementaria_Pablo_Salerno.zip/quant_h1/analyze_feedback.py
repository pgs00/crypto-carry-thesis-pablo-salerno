#!/usr/bin/env python3
"""Reproduce the feedback additions from the pinned public thesis evidence.

Python standard library only. Run `python analyze_feedback.py`; use --download
to retrieve missing inputs. Outputs are descriptive and do not rerun portfolios.
"""
import argparse
import csv
import hashlib
import io
import json
from bisect import bisect_right
from collections import Counter, defaultdict
from datetime import datetime, timezone
from decimal import Decimal as D
from pathlib import Path
from statistics import median
from urllib.request import urlopen
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / 'inputs'
OUTPUT = ROOT / 'outputs'
REPO = 'pgs00/crypto-carry-thesis-pablo-salerno'
REF = '8b395342b7e3a9dd1fbb59f72bee6b5e6efebb49'
HOUR = 3_600_000_000_000
SYMBOLS = ['BTCUSDT', 'ETHUSDT']
SOURCES = {
    'carteras_continuas.zip': (
        'data/evidence/carteras_continuas.zip',
        'ed62babc4eaa33fe960b962c77a032d910877991'),
    'funding_consumido.csv': (
        'results/senal/evidencia/fuentes/funding_consumido.csv',
        '4cb15cd8b87b6fbdb04b0d02c7b3b77511aef70b'),
    'h1_original.csv': (
        'results/senal/evidencia/hipotesis/BASE_E3/h1_observaciones.csv',
        '5b4fbfa7d35326bd1f6edc452c556f6ae20138db'),
}


def yes(value):
    return str(value).lower() == 'true'


def utc(ns):
    return datetime.fromtimestamp(int(ns) / 1e9, timezone.utc).isoformat()


def read_csv(path):
    with path.open(newline='') as file:
        return list(csv.DictReader(file))


def zip_csv(archive, name):
    with archive.open(name) as raw:
        return list(csv.DictReader(io.TextIOWrapper(raw)))


def write_csv(name, rows):
    with (OUTPUT / name).open('w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def groups(rows, date_field):
    """Membership uses the signal/settlement date; periods overlap intentionally."""
    yield 'full', rows
    yield '2022-2023', [r for r in rows if r[date_field][:4] < '2024']
    yield '2024-2026-08', [r for r in rows if r[date_field][:4] >= '2024']
    for year in range(2022, 2027):
        yield str(year), [r for r in rows if r[date_field].startswith(str(year))]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--download', action='store_true')
    args = parser.parse_args()
    INPUT.mkdir(exist_ok=True)
    OUTPUT.mkdir(exist_ok=True)
    provenance = []
    for name, (path, sha) in SOURCES.items():
        local = INPUT / name
        url = f'https://raw.githubusercontent.com/{REPO}/{REF}/{path}'
        if not local.exists() and args.download:
            with urlopen(url, timeout=120) as response:
                local.write_bytes(response.read())
        content = local.read_bytes()
        # apply_patch may add one final LF. Recover exact Git bytes if necessary.
        candidates = [content, content.rstrip(b'\n') + b'\n', content.rstrip(b'\n')]
        exact = next((data for data in candidates if hashlib.sha1(
            f'blob {len(data)}\0'.encode() + data).hexdigest() == sha), None)
        if exact is None:
            raise AssertionError(f'Pinned Git blob verification failed: {name}')
        if content != exact:
            local.write_bytes(exact)
        provenance.append(dict(local_file=name, repository_path=path, ref=REF,
            git_blob_sha1=sha, sha256=hashlib.sha256(exact).hexdigest(),
            bytes=len(exact), url=url))

    funding = read_csv(INPUT / 'funding_consumido.csv')
    published = read_csv(INPUT / 'h1_original.csv')
    with ZipFile(INPUT / 'carteras_continuas.zip') as archive:
        original_h1 = zip_csv(archive, 'tablas/h1_observaciones.csv')
        original_funding = zip_csv(archive, 'evidencia/funding_mercado_y_marks.csv')
        signals = [r for r in zip_csv(archive, 'evidencia/signals.csv')
                   if r['strategy'] == 'conditional']
        reference_summary = zip_csv(archive, 'tablas/h1_resumen.csv')
        reference_filters = zip_csv(archive, 'tablas/filtros_entrada.csv')
    assert len(signals) == len(original_h1) == len(published) == 10224
    assert len(funding) == len(original_funding) == 10316
    assert [dict((k, r[k]) for k in original_h1[0]) for r in published] == original_h1
    assert [dict((k, r[k]) for k in funding[0]) for r in original_funding] == funding
    assert len({(r['symbol'], r['time_ns']) for r in signals}) == len(signals)

    history = {}
    for symbol in SYMBOLS:
        rows = sorted([r for r in funding if r['symbol'] == symbol],
                      key=lambda r: int(r['funding_time']))
        times = [int(r['funding_time']) for r in rows]
        assert len(times) == len(set(times))
        history[symbol] = (rows, times)

    # Normalize each estimator by observed interval duration. An equal observation
    # weight means sum(rate)/sum(hours), matching EWMA with all weights set to 1.
    # Neither estimator assumes a future settlement count or future calendar.
    def prediction(row, window_hours, exponential=False):
        rows, times = history[row['symbol']]
        anchor, decision = int(row['anchor']), int(row['time_ns'])
        left = bisect_right(times, anchor - window_hours * HOUR)
        right = bisect_right(times, anchor)
        assert left > 0 and right > left and times[right - 1] == anchor
        checked = rows[left - 1:right]
        assert all(yes(r['interval_verified']) and D(r['interval_hours']) > 0
                   and int(r['available_at']) <= decision for r in checked)
        rate_sum = D(0)
        duration_sum = D(0)
        for i in range(left, right):
            r = rows[i]
            hours = D(times[i] - times[i - 1]) / HOUR
            assert hours == D(r['interval_hours'])
            weight = (D(2) ** (-D(anchor - times[i]) / HOUR / 24)
                      if exponential else D(1))
            rate_sum += weight * D(r['funding_rate'])
            duration_sum += weight * hours
        return D(168) * rate_sum / duration_sum, right - left, duration_sum

    paired = []
    maximum_ewma_difference = D(0)
    for row in published:
        if not yes(row['horizon_valid']):
            continue
        recalculated, _, _ = prediction(row, 336, exponential=True)
        maximum_ewma_difference = max(maximum_ewma_difference,
                                       abs(recalculated - D(row['forecast'])))
        assert recalculated == D(row['forecast'])
        sma7, n7, hours7 = prediction(row, 168)
        sma14, n14, hours14 = prediction(row, 336)
        # Constant reference: 0.01% per 8 hours, projected for 168 hours.
        constant = D('0.0001') / D(8) * D(168)
        target = D(row['realized'])
        out = dict(symbol=row['symbol'], time_ns=row['time_ns'],
            signal_utc=row['signal_utc'], anchor=row['anchor'], realized=target,
            ewma=D(row['forecast']), no_change=D(row['no_change']),
            rolling_7d=sma7, rolling_14d=sma14, constant_001pct_8h=constant,
            rolling_7d_events=n7, rolling_14d_events=n14,
            rolling_7d_hours=hours7, rolling_14d_hours=hours14)
        for method in ['ewma','no_change','rolling_7d','rolling_14d','constant_001pct_8h']:
            out['absolute_error_' + method] = abs(out[method] - target)
        paired.append(out)
    assert len(paired) == 10180
    write_csv('h1_paired_observations.csv', paired)

    methods = ['ewma','no_change','rolling_7d','rolling_14d','constant_001pct_8h']
    summaries = []
    relative = []
    for period, group in groups(paired, 'signal_utc'):
        asset_maes = {}
        for symbol in SYMBOLS:
            subset = [r for r in group if r['symbol'] == symbol]
            asset_maes[symbol] = {m: sum(r['absolute_error_' + m] for r in subset)
                                   / len(subset) * 10000 for m in methods}
        for symbol in SYMBOLS + ['EQUAL_WEIGHT']:
            subset = group if symbol == 'EQUAL_WEIGHT' else [r for r in group if r['symbol'] == symbol]
            maes = ({m: sum(asset_maes[s][m] for s in SYMBOLS) / 2 for m in methods}
                    if symbol == 'EQUAL_WEIGHT' else asset_maes[symbol])
            summaries.append(dict(period=period, symbol=symbol, observations=len(subset),
                **{'mae_' + m + '_bps': maes[m] for m in methods}))
            for benchmark in methods[1:]:
                relative.append(dict(period=period, symbol=symbol, benchmark=benchmark,
                    observations=len(subset), mae_ewma_bps=maes['ewma'],
                    mae_benchmark_bps=maes[benchmark],
                    ewma_improvement_pct=(1 - maes['ewma'] / maes[benchmark]) * 100,
                    ewma_minus_benchmark_bps=maes['ewma'] - maes[benchmark]))
    write_csv('h1_mae_summary.csv', summaries)
    write_csv('h1_relative_improvement.csv', relative)
    # Original rounded output must be exactly preserved on the same sample.
    for ref in reference_summary:
        new = next(r for r in summaries if r['period'] == ref['period'] and r['symbol'] == ref['symbol'])
        assert abs(new['mae_ewma_bps'] / 10000 - D(ref['mae_ewma'])) < D('1e-27')
        assert abs(new['mae_no_change_bps'] / 10000 - D(ref['mae_no_change'])) < D('1e-27')

    # Basis is an observed futures/spot price ratio at conditional signal times,
    # regardless of whether funding, the basis gate, or portfolio state permits entry.
    basis_rows = []
    max_basis_price_difference = D(0)
    for r in signals:
        basis = D(r['basis']) if r['basis'] else None
        raw_basis = D(r['basis_raw']) if r['basis_raw'] else None
        if raw_basis is not None:
            assert r['spot_price'] and r['futures_price']
            ratio = D(r['futures_price']) / D(r['spot_price']) - 1
            max_basis_price_difference = max(max_basis_price_difference, abs(raw_basis - ratio))
            assert abs(raw_basis - ratio) < D('1e-24')
        if basis is not None:
            assert basis == raw_basis
        basis_rows.append(dict(symbol=r['symbol'], time_ns=r['time_ns'],
            signal_utc=r['timestamp_utc'], basis=basis, basis_raw=raw_basis,
            basis_bps=basis * 10000 if basis is not None else '',
            spot_price=r['spot_price'], futures_price=r['futures_price'],
            filter_data_valid=r['filter_data_valid'],
            filter_basis_negative=r['filter_basis_negative'],
            filter_basis_above_max=r['filter_basis_above_max'],
            source_run_id=r['source_run_id']))
    assert Counter((r['filter_basis_negative'], r['filter_basis_above_max'])
                   for r in basis_rows) == Counter({('fail','pass'):8850,
                   ('pass','pass'):1373, ('not_evaluable','not_evaluable'):1})
    assert sum(r['basis'] is not None for r in basis_rows) == 10223
    write_csv('basis_signal_observations.csv', basis_rows)
    basis_summary = []
    for period, group in groups(basis_rows, 'signal_utc'):
        for symbol in SYMBOLS + ['POOLED']:
            subset = group if symbol == 'POOLED' else [r for r in group if r['symbol'] == symbol]
            values = [r['basis'] * 10000 for r in subset if r['basis'] is not None]
            basis_summary.append(dict(period=period, symbol=symbol,
                total_observations=len(subset), valid_observations=len(values),
                missing_observations=len(subset) - len(values),
                mean_basis_bps=sum(values) / len(values), median_basis_bps=median(values),
                min_basis_bps=min(values), max_basis_bps=max(values),
                negative_observations=sum(v < 0 for v in values),
                negative_pct=D(sum(v < 0 for v in values)) / len(values) * 100))
    write_csv('basis_summary.csv', basis_summary)

    annual_rows = []
    for r in funding:
        date = utc(r['funding_time'])
        if '2022' <= date[:4] <= '2026':
            assert yes(r['interval_verified'])
            annual_rows.append(dict(symbol=r['symbol'], settlement_utc=date,
                rate=D(r['funding_rate']), hours=D(r['interval_hours'])))
    annual_summary = []
    for year in range(2022, 2027):
        for symbol in SYMBOLS:
            subset = [r for r in annual_rows if r['symbol'] == symbol
                      and r['settlement_utc'].startswith(str(year))]
            total_rate = sum(r['rate'] for r in subset)
            total_hours = sum(r['hours'] for r in subset)
            annual_summary.append(dict(year=year, symbol=symbol, observations=len(subset),
                first_settlement_utc=subset[0]['settlement_utc'],
                last_settlement_utc=subset[-1]['settlement_utc'],
                covered_interval_hours=total_hours,
                funding_rate_sum_pct=total_rate * 100,
                mean_funding_normalized_8h_pct=total_rate / total_hours * 8 * 100,
                simple_annualized_funding_pct=total_rate / total_hours * 8760 * 100,
                min_interval_hours=min(r['hours'] for r in subset),
                max_interval_hours=max(r['hours'] for r in subset)))
    write_csv('funding_by_year.csv', annual_summary)
    audit = dict(repository=REPO, ref=REF, sources=provenance,
        original_observations=len(published), paired_valid_observations=len(paired),
        original_exclusions=dict(Counter(r['reason'] for r in published if not yes(r['horizon_valid']))),
        funding_observations=len(funding), conditional_signal_observations=len(signals),
        conditional_basis_observations=sum(r['basis'] is not None for r in basis_rows),
        maximum_ewma_recalculation_difference=str(maximum_ewma_difference),
        maximum_basis_price_ratio_difference=str(max_basis_price_difference),
        original_h1_and_funding_identical_to_E3_zip=True,
        original_mae_summary_reproduced=True,
        constant_forecast_bps='21', selection_threshold_bps='34',
        constant_forecast_above_threshold=False,
        methodology={
            'horizon_hours':168, 'ewma_window_hours':336, 'ewma_half_life_hours':24,
            'rolling_windows_hours':[168,336],
            'rolling_formula':'168 * sum(realized funding rates) / sum(actual verified interval hours)',
            'past_window':'anchor-window < funding_time <= anchor; predecessor also checked',
            'causality':'All historical rows and predecessor available_at <= original signal time; no future count/calendar assumed',
            'target':'Original realized funding label in (signal_time, signal_time+168h], unchanged',
            'comparison':'Same 10,180 original valid observations; equal weight of per-asset MAEs',
            'relative_improvement':'100 * (1 - MAE_EWMA / MAE_benchmark); negative means EWMA worse',
            'basis':'10000*(futures_price/spot_price-1), evaluable conditional signal observations; one data-invalid BTC signal excluded even though a raw price ratio exists; pooled median is median over the pooled values',
            'annual_funding':'100*8760*sum(funding_rate)/sum(actual interval_hours), grouped by settlement year; simple, no reinvestment',
        },
        limitations=[
            'Descriptive post-feedback benchmarks; parameters were not pre-registered and no new portfolio is simulated.',
            'Overlapping 168-hour targets produce dependent errors; no significance inference for the new comparisons.',
            'Basis statistics describe signal-time snapshots, not every minute or executed trades.',
            'Annual funding is a market-rate descriptor, not account return: it excludes spot/perpetual basis, fees, margin, idle cash and reinvestment.',
            '2026 covers January through August only. Funding intervals are attributed to settlement year, including the first interval that begins in the previous year.',
            'Original source data are checked against the frozen repository; this is not independent exchange-data authentication.',
        ])
    (OUTPUT / 'audit_and_provenance.json').write_text(json.dumps(audit, indent=2, ensure_ascii=False) + '\n')
    print(json.dumps({k:v for k,v in audit.items() if k not in ['sources','methodology','limitations']}, indent=2))
    for r in summaries:
        if r['symbol'] == 'EQUAL_WEIGHT':
            print(r['period'], r['observations'], {k:round(float(v),4) for k,v in r.items() if k.startswith('mae_')})
    for r in basis_summary:
        if r['symbol'] == 'POOLED':
            print('BASIS', r['period'], r['valid_observations'], float(r['mean_basis_bps']), float(r['median_basis_bps']))
    for r in annual_summary:
        print('FUNDING', r['year'], r['symbol'], float(r['simple_annualized_funding_pct']))


if __name__ == '__main__':
    main()
