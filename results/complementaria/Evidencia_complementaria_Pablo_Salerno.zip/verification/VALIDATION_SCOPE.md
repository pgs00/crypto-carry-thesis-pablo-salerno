# Alcance y versiones de la comprobación

La suite preparada se ejecutó completa con el primer comparador portable y la
corrección del fixture: **1411 passed, 48 skipped**. Las omisiones corresponden a
pruebas que exigen las variables de paquete `COST_CAPACITY_PACKAGE`,
`EXECUTION_DELAYS_PACKAGE` o `SENAL_PACKAGE`; no se contabilizan como pases.

La preparación resolvió dos fallos ambientales previamente conservados en el log:
objetos Git faltantes en el clone filtrado/superficial y sockets AF_UNIX prohibidos
para `forkserver`. Se materializó el checkout y el commit de publicación con su
padre, y se ejecutó la suite con contexto `spawn`, sin modificar producto ni
aserciones. La suite predeterminada anterior produjo **1409 passed, 2 failed,
48 skipped**. No se confunden esas dos ejecuciones.

B2, B3 y B6 usan la política conservada en `audit_code_v1/scripts`, cuyos hashes
figuran en sus JSON. La política final del parche añade únicamente las columnas
de formato largo `comparator_value`, `general_value`, `close_only_value` y
`close_minus_general`, presentes en los contrastes CAGR de B5 y B4. Se mantienen
la identidad exacta de `metric` y el conjunto acotado de métricas autorizadas.
Ese cambio final pasó **30 pruebas dirigidas**, incluidas aceptación de último
decimal y rechazo de cambios monetarios o de identidad de métrica. B4 y B5 se
verifican con esa política final. El inventario de esquemas consumidos está en
`long_format_schema_inventory.json`.

Cada informe de bloque conserva `overlay_sha256` y `numeric_policy_sha256` de su
ejecución. El wrapper también rechaza una modificación de esas fuentes durante
la ejecución. La comparación numérica nueva no sustituye la identidad por hashes:
se autentican antes/después los mismos manifiestos y miembros publicados.

Las primeras ejecuciones concurrentes de los paquetes más grandes agotaron el
límite de 8 GiB del entorno; se repitieron de forma individual. Un código -9 no se
presenta como fallo económico ni como pase. El verificador original de B5 quedó
interrumpido en aquella tanda: su estado original no se transforma retrospectivamente
en un resultado positivo por el pase de la capa externa.
