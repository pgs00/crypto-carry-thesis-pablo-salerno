"""Run compact audits sequentially, in a new directory outside the checkout."""
import argparse
import csv
import json
import subprocess
import time
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--mode', choices=['original', 'portable', 'all'], default='portable')
args = parser.parse_args()
repo, output = args.repo.resolve(), args.output.resolve()
if output.exists() or output.is_relative_to(repo):
    raise ValueError('Choose a new audit directory outside the checkout')
output.mkdir(parents=True)
python = repo / ('.venv/Scripts/python.exe' if __import__('os').name == 'nt' else '.venv/bin/python')
packages = {r['id']: repo/r['paquete_vigente'] for r in csv.DictReader(
    (repo/'results/matriz_resultados.csv').open(encoding='utf8')) if r['paquete_vigente']}
parent = repo/'data/evidence/reglas_historicas'
commands = {
    'BASE': [packages['BASE']/'herramientas/verify_rules_sensitivity_correction.py', '--package', packages['BASE'], '--parent', parent],
    'RIESGO': [packages['RIESGO']/'herramientas/scripts/verify_intraday_risk.py', '--scope', 'compact', '--package', packages['RIESGO'], '--parent', parent, '--correction', packages['BASE']],
    'B1_CAPITAL': [packages['B1_CAPITAL']/'herramientas/scripts/verify_return_capital.py', '--package', packages['B1_CAPITAL']],
    'B1_SOFR': [packages['B1_SOFR']/'herramientas/scripts/verify_sofr_benchmark.py', '--package', packages['B1_SOFR'], '--previous', packages['B1_CAPITAL']],
    'B2': [packages['B2']/'herramientas/scripts/verify_signal_sensitivity.py', '--package', packages['B2']],
    'B3': [packages['B3']/'herramientas/scripts/verify_cost_capacity.py', '--package', packages['B3']],
    'B4': [packages['B4']/'herramientas/scripts/verify_execution_delays.py', '--package', packages['B4']],
    'B5': [packages['B5']/'herramientas/scripts/verify_stress_counterfactual.py', packages['B5']],
    'B6': ['-I', packages['B6']/'herramientas/scripts/verify_stability_uncertainty.py', '--candidate', packages['B6'], '--forbid-root', 'D:/Backtesting'],
}
selected = []
for block, original in commands.items():
    if args.mode in {'original', 'all'} or block not in {'B2', 'B3', 'B4', 'B5', 'B6'}:
        selected.append((block+'_original', original))
    if args.mode in {'portable', 'all'} and block in {'B2', 'B3', 'B4', 'B5', 'B6'}:
        selected.append((block+'_portable', [repo/'scripts/verify_compact_portable.py', '--block', block, '--package', packages[block]]))
results = []
for label, command in selected:
    command = list(map(str, [python, '-B', '-X', 'utf8', *command, '--output', output/(label+'.json')]))
    started = time.monotonic()
    with (output/(label+'.log')).open('x', encoding='utf8') as log:
        process = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    result = dict(label=label, command=command, exit_code=process.returncode, seconds=time.monotonic()-started)
    results.append(result)
    (output/'command_results.json').write_text(json.dumps(results, indent=2)+'\n', encoding='utf8')
    print(json.dumps(result), flush=True)
raise SystemExit(0 if all(r['exit_code'] == 0 for r in results) else 1)
