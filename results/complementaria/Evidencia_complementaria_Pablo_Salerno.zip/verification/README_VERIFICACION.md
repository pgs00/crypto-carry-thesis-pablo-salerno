# Revisión técnica reproducible

Base: `pgs00/crypto-carry-thesis-pablo-salerno` en
`8b395342b7e3a9dd1fbb59f72bee6b5e6efebb49`.

El parche modifica únicamente pruebas/documentación y añade dos herramientas
fuera de las evidencias selladas. Los paquetes publicados, las carteras y sus
manifiestos no se modifican. El entorno usa CPython 3.14.3, NumPy 2.3.5,
pandas 2.3.3, PyArrow 25.0.1 y Nautilus Trader 1.231.0, instalados con `uv.lock`.

## Archivos

- `reproducibility.patch`: parche aplicable al commit base, sin commits ni push.
- `patched_files/docs/portable_verification.md`: contrato de tolerancias y comandos.
- `reproduce_compact.py`: ejecutor secuencial portable de los nueve bloques;
  `--mode original` conserva los nueve comandos congelados y `--mode all` ejecuta ambos alcances.
- `logs/original_results.json`: códigos y comandos de la verificación literal.
- `logs/*overlay.json`: resultados de la capa externa, separados de los originales.
- `logs/suite_verified.log`: suite completa predeterminada.
- `logs/bootstrap_spawn_check.log`: diagnóstico aislado del contexto `spawn`.
- `logs/git_integrity.json`: diferencia vacía en `results` y `data/evidence`.
- `risk_exit_trace.md`: causa y cronología del incidente del 24/03/2023, con fuentes.
- `ANEXO_B_REEMPLAZO.md`: redacción y estado final de esta revisión.

`VALIDATION_SCOPE.md` distingue resultados finales, pruebas previas, versiones
y fallos de preparación. Los logs previos relevantes se conservan identificados;
los directorios de trabajo y caches no forman parte de esta entrega.

## Reproducir el parche

```bash
git clone https://github.com/pgs00/crypto-carry-thesis-pablo-salerno.git crypto-carry
cd crypto-carry
git checkout 8b395342b7e3a9dd1fbb59f72bee6b5e6efebb49
git apply --check ../reproducibility.patch
git apply ../reproducibility.patch
uv --cache-dir .uv-cache sync --frozen --python 3.14.3
.venv/bin/python -B -X utf8 -m pytest tests -q -p no:cacheprovider --basetemp ../pytest_nuevo
```

La suite puede requerir objetos Git históricos que un clone filtrado o superficial
no tiene. La preparación usada se documenta en `logs/complete_checkout.log`.
La restricción de sockets AF_UNIX del entorno de esta revisión afecta al
`forkserver` de Python 3.14. No se relaja una aserción para convertirlo en pase:
se conserva el resultado predeterminado; primero se probó aisladamente `spawn`
y después se ejecutó la suite completa preparada (1411 pases, 48 omisiones).

## Diferenciar identidad y recálculo

La capa externa autentica cada archivo antes de cargar código congelado y otra
vez al terminar. Conserva el control contable de `1E-8` USDT. Solo permite el
presupuesto absoluto de redondeo documentado para estadísticas CAGR; en el CSV
bootstrap utiliza el `SCALAR_ATOL=2e-11` ya fijado para JSON/Parquet. Toda
diferencia aceptada queda en el JSON. Los estados/categorías/IDs/conteos y los
CSV de estrés frente a sus Parquet persistidos siguen siendo exactos.

Un pase compacto comprueba sellos, agregados, inputs compactos y cálculos del
alcance indicado. No acredita nuevos backtests ni una relectura de las fuentes
masivas de mercado, ni sustituye el criterio de éxito económico.

Ejecutor de los nueve bloques sin concurrencia pesada:

```bash
python reproduce_compact.py --repo /ruta/crypto-carry --output /ruta/auditoria_nueva --mode portable
```

Los hashes de versión por bloque y los resultados finales se resumen en
`verification_summary.json`; las fuentes exactas de la primera política están
en `audit_code_v1/`, y la política final está en el parche y `patched_files/`.

## Comando exacto de la suite preparada

Desde `verification/repo`, en el checkout filtrado de esta revisión, se ejecutaron
estos comandos para materializar los archivos y recuperar publicación y padre:

```bash
git sparse-checkout disable
git fetch --depth=1 --no-filter origin 894059e4ce318e51f25211d04be9f0202de90ae7:refs/heads/test-provenance-reference
git fetch --depth=2 --no-filter origin 894059e4ce318e51f25211d04be9f0202de90ae7:refs/heads/test-provenance-reference
```

El primer fetch permitió clonar; el segundo añadió el padre necesario
`80feefc45872d2c48c33f3fbc3ebc9eb402eee6a`. Un clone completo con la historia
ya disponible no requiere esta preparación adicional. El comando exacto que
produjo `logs/suite_prepared_complete.log` fue:

```bash
.venv/bin/python -B -X utf8 -c "import multiprocessing,pytest; multiprocessing.set_start_method('spawn'); raise SystemExit(pytest.main(['tests','-q','-p','no:cacheprovider','--basetemp','../pytest_prepared_complete']))" > ../logs/suite_prepared_complete.log 2>&1
```

El directorio `../logs` ya existía y el temporal de pytest era nuevo. La ejecución
con 1411 pases corresponde a la política inicial documentada; el parche final
añade cuatro casos parametrizados para los alias de B4/B5, incluidos en las
30 pruebas dirigidas finales. No se atribuye a la suite inicial un conteo posterior.

Las copias de presentación de los registros omiten la fecha de verificación y normalizan las rutas locales respecto de `verification/`. Se conservan las versiones, los códigos de salida, los resultados y las identidades de los insumos. Los snapshots y el parche retienen las referencias históricas necesarias para autenticar y reproducir el experimento.
