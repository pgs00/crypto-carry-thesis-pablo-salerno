# Trazado verificado: salida por riesgo del 24/03/2023

Revisión de solo lectura contra `pgs00/crypto-carry-thesis-pablo-salerno`, commit `8b395342b7e3a9dd1fbb59f72bee6b5e6efebb49`. Se contrastaron los Parquet originales de BASE_E3 con el código archivado en `data/evidence/reglas_historicas/codigo_ejecutado/`; no se modificó el repositorio cacheado ni el remoto.

## Hallazgo principal

La causa exacta fue **`real_market_inactivity` a las 11:59 UTC**, con `liquidation=false`. No fue una llamada de margen, liquidación ni ensanchamiento del basis. El futuro aparece cerrado a las **12:00** porque el fill del modelo `next_minute_vwap` se registra al final de la ventana de ejecución **11:59–12:00**. La venta spot se registra a las **14:01**, al terminar la primera ventana spot válida de reapertura **14:00–14:01**. Por tanto, las 12:00 son la hora del fill y del inicio del tramo descubierto, no la hora de la decisión de salida.

| UTC, 24/03/2023 | Evidencia y significado |
|---|---|
| 11:27–11:28 | Última vela spot operativa; su `event_time` es `end_time=11:28`. |
| 11:28–14:00 | Minutos completos de suspensión spot documentada, intervalo semiabierto. |
| 11:58 | Edad de la observación spot = 1.800 s; aún no activa el umbral estricto `>`. |
| 11:59 | Edad = 1.860 s; `close_requested: real_market_inactivity`, transición `HOLDING → CLOSING_PERP`. |
| 12:00 | Fill BUY `close_perp` para la ventana 11:59–12:00; transición `CLOSING_PERP → CLOSING_SPOT`. |
| 12:01–14:00 | Intentos spot expiran por `timeout` y se reenvían. No se inventan fills durante la suspensión. |
| 14:01 | Fill SELL `close_spot` para la ventana 14:00–14:01; `unwind_complete → COOLDOWN`. |

La cronología se verifica en ambas corridas originales:
- Condicional: `run_ad71d751b20623006c195ff3`, ETHUSDT.
- Permanente: `run_dfea4b7ac1475668d5968c97`, BTCUSDT y ETHUSDT.

## Fills originales (precios en USDT por unidad)

| Estrategia / activo | Orden futuro, BUY 12:00 | Cantidad | Precio futuro | Orden spot, SELL 14:01 | Cantidad | Precio spot |
|---|---|---:|---:|---|---:|---:|
| Condicional / ETH | conditional-00000017 | 1,675 | 1.746,83 | conditional-00000138 | 1,6750 | 1.770,96 |
| Permanente / BTC | permanent-00000093 | 0,109 | 27.592,20 | permanent-00000335 | 0,10900 | 27.972,48 |
| Permanente / ETH | permanent-00000094 | 1,738 | 1.746,83 | permanent-00000336 | 1,7380 | 1.770,96 |

Los precios de ambas patas corresponden a ventanas distintas; su diferencia no es un basis simultáneo ni prueba una ganancia libre de riesgo. Los fills son resultados de una simulación con VWAP, slippage y redondeo, no ejecuciones reales de una cuenta.

## Por qué el motor cierra antes el futuro

La política de desarme está codificada: si existe short, `_close` envía primero BUY de futuros; solo después de ese fill pasa a vender spot. El contrato perpetuo seguía teniendo una ventana válida mientras el spot no la tenía. El calendario de suspensión impide tratar esas velas ausentes como error fatal o inventar liquidez; no dispara por sí mismo la salida. El disparador observado es el contador de inactividad, medido con información ya disponible.

Al recomprar el short se elimina su exposición de margen/mantenimiento, pero queda inventario spot largo sin cobertura durante **7.260 s = 121 min**. Es una decisión operacional de la estrategia, no una salida simultánea ni una garantía de neutralidad continua. El riesgo posterior es direccional y de ejecución del spot. El comportamiento es coherente con esa política, aunque evaluar si convenía mantener la cobertura hasta la reapertura exigiría otro contrafactual; este trazado no demuestra que la política sea óptima.

El reporte de riesgo registra P&L contemporáneo de cartera de −34,05 USDT (condicional) y −50,11 USDT (permanente) en ese tramo. No debe llamarse pérdida causal de la suspensión ni del cierre anticipado sin un contrafactual. La cotización spot original queda antigua durante el hueco; el proxy es hipotético y cambia la valoración, no los fills. Tampoco deben sumarse los 121 minutos BTC y ETH simultáneos: son 121 minutos por unión temporal de cartera.

## Fuentes exactas y líneas

Prefijo de enlaces: `https://github.com/pgs00/crypto-carry-thesis-pablo-salerno/blob/8b395342b7e3a9dd1fbb59f72bee6b5e6efebb49/`.

1. `data/evidence/reglas_historicas/corridas/run_ad71d751b20623006c195ff3/risk_events.parquet` y equivalente `run_dfea4b7ac1475668d5968c97/risk_events.parquet`: eventos originales de 11:59, 12:00 y 14:01; filtrados legibles en los `risk_events_march24.csv` locales adyacentes.
2. Los `fills.parquet` de esas mismas dos corridas: `time_ns`, `window_start_utc`, `window_end_utc`, cantidad, precio y orden; filtrados en `fills_march24.csv`.
3. `data/evidence/reglas_historicas/corridas/run_ad71d751b20623006c195ff3/effective_config.toml`, líneas 27–33: `inactivity_seconds=1800`, `execution_model="next_minute_vwap"`, señales de minuto cerrado.
4. `data/evidence/reglas_historicas/codigo_ejecutado/src/crypto_carry/strategy.py`: 318–345 (short primero), 347–381 (prioridad de chequeos y umbral estricto), 418–436 (reintento tras timeout), 636–659 (desfase cero en modo minuto y transición a spot), 788–806 (sin fill si falta vela durante cierre documentado), 921–926 (última vela con volumen), 1017–1024 (fills de ventana antes de chequeo periódico), 1041–1061 (ejecución/reintentos de cierre).
5. `data/evidence/reglas_historicas/codigo_ejecutado/src/crypto_carry/models.py`, 50–73: una vela solo es observable al final exclusivo y `event_time=end_time`.
6. `data/evidence/reglas_historicas/codigo_ejecutado/src/crypto_carry/execution.py`, 12–20: primera ventana completa no anterior al envío y VWAP = quote/base.
7. `data/evidence/reglas_historicas/codigo_ejecutado/src/crypto_carry/data/market_calendar.py`, 23–31: suspensión spot 11:28–14:00; 35–47: intervalo semiabierto.
8. `results/riesgo/README.md`, 204–221: ancla/reapertura, 121 min, mantenimiento cero tras el cierre del futuro y límites de interpretación; 249–256: P&L contemporáneo distinto del efecto causal.
9. `results/riesgo/evidencia/tablas/catalogo_incidentes.csv`: filas BASE_E3 del 24/03; estados, causas y 7.260 s.

Todas las fuentes descargadas están bajo `verification/sources/` conservando su ruta de repositorio. Los archivos `.parquet.b64` conservan la respuesta original del conector; los `.parquet` son su decodificación. El código actual en `src/` tiene números de línea distintos: para esta explicación se cita expresamente el código ejecutado archivado.

## Redacción lista para incorporar

«El 24 de marzo de 2023 la regla de inactividad solicitó el cierre a las 11:59 UTC, cuando habían transcurrido más de 1.800 segundos desde la última vela spot disponible. El motor desarma primero el perpetuo: su recompra se contabiliza a las 12:00, al terminar la ventana VWAP 11:59–12:00. La venta spot no puede completarse durante la suspensión y se contabiliza a las 14:01, al cierre de la primera ventana válida tras la reapertura, 14:00–14:01. Los 121 minutos intermedios son exposición larga spot sin cobertura, no una liquidación por margen. Esta secuencia describe la política de cierre implementada; no demuestra que fuera la política óptima ni permite atribuir causalmente todo el P&L del tramo a la interrupción.»

