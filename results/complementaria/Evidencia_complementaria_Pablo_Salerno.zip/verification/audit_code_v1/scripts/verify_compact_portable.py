"""Explicit, read-only comparator overlay over authenticated frozen B2-B6 tools.

Does not modify any package, source snapshot, finance tolerance, output or seal.
Run one block per fresh Python process. This is a new verification result, not a
claim that the original literal verifier passed on this operating system.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import platform
import sys
from datetime import UTC, datetime
from pathlib import Path

sys.dont_write_bytecode = True
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[name] = "1"

# Load the small overlay by file: do not bind the scripts package to this checkout.
# Frozen imports must resolve to the unchanged package's herramientas/scripts.
POLICY_PATH = Path(__file__).with_name("compact_numeric_policy.py")
policy_spec = importlib.util.spec_from_file_location("_compact_numeric_policy", POLICY_PATH)
policy = importlib.util.module_from_spec(policy_spec)
policy_spec.loader.exec_module(policy)
VERIFIERS = {
    "B2": "verify_signal_sensitivity.py",
    "B3": "verify_cost_capacity.py",
    "B4": "verify_execution_delays.py",
    "B5": "verify_stress_counterfactual.py",
    "B6": "verify_stability_uncertainty.py",
}
REVIEWED_COMMIT = "8b395342b7e3a9dd1fbb59f72bee6b5e6efebb49"
MANIFESTS = {
    "B2": "e3f15d7754043fa956404ae79734115527cc3d798275bbbaf838d827dad68837",
    "B3": "4a945144d83b3311c942a104d2dc5ebdac0d2ecfde6b40a5691adae558ab93f4",
    "B4": "41a4c05b36be6c4d42878b7755f18b3ade7c0c94700fc38db43aa1a548e93eba",
    "B5": "ab22322dfa512221fecdccb5f01bf1aca98bca8c11130b6abc1537a082d35072",
    "B6": "dafd82aaa77ed419298bcae0a4eaec5f8465a98b70b4892566e1a49aeb4e8f77",
}


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    overlay_hash, policy_hash = sha(__file__), sha(POLICY_PATH)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--block", choices=VERIFIERS, required=True)
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--forbid-root", action="append", default=["D:/Backtesting"])
    args = parser.parse_args()
    package = args.package.resolve()
    output = args.output.resolve()
    if output.exists() or output.is_relative_to(package):
        raise ValueError("Audit output must be new and outside protected inputs")
    for parent in [output.parent, *output.parents]:
        if (parent / "manifiesto_paquete.json").exists():
            raise ValueError("Audit output cannot be inside a sealed ancestor")
    authentication = policy.authenticate_package(package, MANIFESTS[args.block])
    frozen_path = package / "herramientas/scripts" / VERIFIERS[args.block]
    spec = importlib.util.spec_from_file_location("_frozen_compact_verifier", frozen_path)
    frozen = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(frozen)
    if args.block in {"B2", "B3", "B4"}:
        frozen.same_rows = policy.same_rows
    elif args.block == "B5":
        frozen.verify_tables = lambda folder, tables: policy.verify_stress_tables(
            folder, tables, frozen
        )
    else:
        frozen.block_original_sources(args.forbid_root)
        from scripts import stability_uncertainty_bootstrap as bootstrap

        bootstrap.verify_csv = lambda path, expected: policy.verify_bootstrap_csv(
            path, expected, abs_tol=bootstrap.SCALAR_ATOL
        )
    result = frozen.verify(package)
    if policy.authenticate_package(package, MANIFESTS[args.block]) != authentication:
        raise ValueError("Package identity changed during verification")
    if sha(__file__) != overlay_hash or sha(POLICY_PATH) != policy_hash:
        raise ValueError("Overlay source changed during verification")
    for name, module in sys.modules.copy().items():
        if name == "scripts" or name.startswith(("scripts.", "crypto_carry")):
            origin = getattr(module, "__file__", None)
            if origin and not Path(origin).resolve().is_relative_to(package / "herramientas"):
                raise ValueError("Imported helper outside authenticated tools: " + name)
    import nautilus_trader
    import numpy
    import pandas
    import pyarrow

    report = dict(
        passed=True,
        verification_mode="portable_comparator_overlay_v1",
        original_literal_verifier_pass_claimed=False,
        verified_utc=datetime.now(UTC).isoformat(),
        block=args.block,
        package_manifest_sha256=sha(package / "manifiesto_paquete.json"),
        reviewed_commit=REVIEWED_COMMIT,
        package_authenticated_before_and_after=authentication,
        frozen_verifier_sha256=sha(frozen_path),
        overlay_sha256=overlay_hash,
        numeric_policy_sha256=policy_hash,
        policy=dict(
            cagr_absolute_tolerance=str(policy.CAGR_ATOL),
            relative_tolerance=0,
            cagr_fields=sorted(policy.CAGR_FIELDS),
            bootstrap_csv_absolute_tolerance="frozen SCALAR_ATOL = 2e-11",
            accounting_tolerance_modified=False,
            sealed_bytes_modified=False,
        ),
        environment=dict(
            python=sys.version,
            platform=platform.platform(),
            numpy=numpy.__version__,
            pandas=pandas.__version__,
            pyarrow=pyarrow.__version__,
            nautilus_trader=nautilus_trader.__version__,
        ),
        accepted_roundoff=policy.ACCEPTED_DIFFERENCES,
        original_checks=result,
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf8") as stream:
        stream.write(json.dumps(report, indent=2, ensure_ascii=False, default=str) + "\n")
    print(
        json.dumps(
            dict(
                passed=True,
                block=args.block,
                mode=report["verification_mode"],
                accepted_roundoff=len(policy.ACCEPTED_DIFFERENCES),
            )
        )
    )


if __name__ == "__main__":
    main()
