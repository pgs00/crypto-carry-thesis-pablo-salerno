"""Narrow postprocessing portability policy; never an accounting tolerance.

CAGR is a dimensionless binary64 pow/subtraction result. We budget 16 machine
 epsilons on that unit scale, independently of any observed discrepancy, with
 no relative tolerance. This is not a bound on arbitrary ill-conditioned data:
 larger discrepancies fail. All other financial fields remain exact here.
Bootstrap CSV uses the frozen verifier's existing SCALAR_ATOL, not a new budget.
"""

from __future__ import annotations

import csv
import json
import math
import sys
from decimal import Decimal, InvalidOperation
from pathlib import Path

CAGR_ATOL = Decimal(16) * Decimal.from_float(sys.float_info.epsilon)
CAGR_FIELDS = frozenset(
    {"cagr", "conditional_cagr", "difference_cagr", "inherited_cagr", "new_cagr", "portfolio_cagr"}
)
ACCEPTED_DIFFERENCES: list[dict] = []


def cell(value):
    if value is None:
        return ""
    if isinstance(value, (list, dict, tuple)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str)
    return str(value)


def _numeric_equal(a, b, tolerance, label):
    try:
        left, right = Decimal(str(a)), Decimal(str(b))
    except InvalidOperation, ValueError:
        return False
    if not left.is_finite() or not right.is_finite():
        return False
    difference = abs(left - right)
    if difference > tolerance:
        return False
    if str(a) != str(b):
        ACCEPTED_DIFFERENCES.append(
            dict(
                location=label,
                observed=str(a),
                recomputed=str(b),
                absolute_difference=str(difference),
                absolute_tolerance=str(tolerance),
            )
        )
    return True


def same_rows(actual, expected, label):
    if len(actual) != len(expected):
        raise ValueError(f"{label}: row count differs")
    fields = set().union(*(set(row) for row in expected))
    if set().union(*(set(row) for row in actual)) != fields:
        raise ValueError(f"{label}: fields differ")
    for index, (a, b) in enumerate(zip(actual, expected, strict=True)):
        # CSV exports the union of asset and portfolio row fields, padding
        # inapplicable fields with empty cells; keep that existing convention.
        for key in fields:
            left, right = cell(a.get(key)), cell(b.get(key))
            location = f"{label}/{index}/{key}"
            cagr_field = key in CAGR_FIELDS or (
                key
                in {
                    "value",
                    "base_value",
                    "delta",
                    "comparator_value",
                    "general_value",
                    "close_only_value",
                    "close_minus_general",
                }
                and a.get("metric") == b.get("metric")
                and b.get("metric") in CAGR_FIELDS
            )
            if cagr_field and left != "" and right != "":
                if _numeric_equal(left, right, CAGR_ATOL, location):
                    continue
            elif left == right:
                continue
            if cagr_field and left == right == "":
                continue
            raise ValueError(f"{location}: value differs")


def verify_bootstrap_csv(path, expected, *, abs_tol):
    with Path(path).open(encoding="utf8", newline="") as stream:
        reader = csv.DictReader(stream)
        fields = list(expected[0]) if expected else []
        if reader.fieldnames != fields:
            raise ValueError("Bootstrap CSV field/order differs")
        actual = list(reader)
    if len(actual) != len(expected):
        raise ValueError("Bootstrap CSV row count differs")
    for index, (a, b) in enumerate(zip(actual, expected, strict=True)):
        if set(a) != set(b):
            raise ValueError("Bootstrap CSV fields differ")
        for key, value in b.items():
            location = f"{Path(path).name}/{index}/{key}"
            if type(value) is float:
                if not math.isfinite(value) or not _numeric_equal(
                    a[key], value, Decimal(str(abs_tol)), location
                ):
                    raise ValueError(f"{location}: numeric value differs")
            else:
                text = (
                    json.dumps(value, ensure_ascii=False)
                    if isinstance(value, (dict, list))
                    else ""
                    if value is None
                    else str(value)
                )
                if a[key] != text:
                    raise ValueError(f"{location}: exact value differs")


def verify_stress_tables(folder, tables, frozen):
    """Authenticate persisted representation exactly, then compare recalculation."""
    inventory = frozen.read_json(folder / "catalogo.json")
    if set(inventory) != set(tables):
        raise ValueError("Derived table population differs from recomputation")
    for name, expected in tables.items():
        actual = frozen.parquet(folder / (name + ".parquet"))
        if inventory[name]["semantic_sha256"] != frozen.table_digest(actual):
            raise ValueError("Persisted table differs from catalog: " + name)
        if inventory[name]["rows"] != len(expected):
            raise ValueError("Derived table row count differs")
        same_rows(actual, frozen.canonical_rows(expected), "recomputed/" + name)
        if inventory[name]["csv_export"] and frozen.read_csv(folder / (name + ".csv")) != actual:
            raise ValueError("CSV export differs from verified Parquet table: " + name)
    return len(tables)


def authenticate_package(package, expected_manifest_sha256):
    """Authenticate every member before any code from a frozen package is loaded."""
    import hashlib
    from pathlib import PurePosixPath

    package = Path(package).resolve()

    def digest(path):
        with path.open("rb") as stream:
            return hashlib.file_digest(stream, "sha256").hexdigest()

    manifest = package / "manifiesto_paquete.json"
    if digest(manifest) != expected_manifest_sha256:
        raise ValueError("Package differs from pinned reviewed manifest")
    if (package / "manifiesto_paquete.sha256").read_text().strip() != expected_manifest_sha256:
        raise ValueError("Package manifest sidecar changed")
    members = json.loads(manifest.read_text(encoding="utf8"))["members"]
    expected = {"manifiesto_paquete.json", "manifiesto_paquete.sha256"}
    for member in members:
        name = member["path"]
        if not isinstance(name, str) or "\\" in name or ":" in name:
            raise ValueError("Unsafe package member path")
        relative = PurePosixPath(name)
        if relative.is_absolute() or ".." in relative.parts or name in expected:
            raise ValueError("Unsafe or duplicate package member path")
        path = package / name
        if not path.resolve().is_relative_to(package) or path.is_symlink() or not path.is_file():
            raise ValueError("Missing or escaping package member")
        if path.stat().st_size != member["bytes"] or digest(path) != member["sha256"]:
            raise ValueError("Changed package member: " + name)
        expected.add(name)
    actual = {p.relative_to(package).as_posix() for p in package.rglob("*") if p.is_file()}
    if expected != actual:
        raise ValueError("Package membership differs")
    return dict(manifest_sha256=expected_manifest_sha256, members=len(members))
