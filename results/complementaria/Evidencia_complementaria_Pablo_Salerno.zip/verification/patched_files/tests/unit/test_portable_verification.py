"""Portability never grants permission to change money, identities or categories."""

import importlib.util

import pytest


def api():
    assert importlib.util.find_spec("scripts.compact_numeric_policy"), "portable comparison absent"
    from scripts import compact_numeric_policy

    return compact_numeric_policy


def test_accepts_last_digit_cagr_without_changing_source_rows():
    actual = [{"run_id": "r", "cagr": "0.0522270351463172"}]
    api().same_rows(actual, [{"run_id": "r", "cagr": 0.05222703514631721}], "metrics")
    assert actual[0]["cagr"] == "0.0522270351463172"


@pytest.mark.parametrize(
    "key,a,b",
    [
        ("cagr", "0.0522270351463172", 0.052227035147),
        ("net_pnl_usdt", "1.0000000000000000", "1.0000000000000001"),
        ("run_id", "1", "1.0"),
        ("days", "1", "1.0"),
        ("verdict", "1", "1.0"),
        ("cagr", "", 0.0),
        ("cagr", "nan", float("nan")),
        ("cagr", "inf", float("inf")),
    ],
)
def test_rejects_nonportable_or_nonfinite_changes(key, a, b):
    with pytest.raises(ValueError):
        api().same_rows([{key: a}], [{key: b}], "metrics")


def test_rejects_changed_schema_and_row_count():
    with pytest.raises(ValueError):
        api().same_rows([{"cagr": None, "x": None}], [{"cagr": None}], "x")
    with pytest.raises(ValueError):
        api().same_rows([], [{"cagr": None}], "x")


def test_bootstrap_csv_numeric_fields_follow_original_scalar_contract(tmp_path):
    p = tmp_path / "bootstrap.csv"
    p.write_text("statistic,point_estimate,valid_replicates\nx,0.0522270351463172,5000\n")
    expected = [dict(statistic="x", point_estimate=0.05222703514631721, valid_replicates=5000)]
    api().verify_bootstrap_csv(p, expected, abs_tol=2e-11)
    p.write_text("statistic,point_estimate,valid_replicates\nx,0.0522270352,5000\n")
    with pytest.raises(ValueError):
        api().verify_bootstrap_csv(p, expected, abs_tol=2e-11)


@pytest.mark.parametrize(
    "line", ["x,nan,5000", "x,0.0522270351463172,5000.0", "y,0.0522270351463172,5000"]
)
def test_bootstrap_csv_preserves_categories_counts_and_finiteness(tmp_path, line):
    p = tmp_path / "bootstrap.csv"
    p.write_text("statistic,point_estimate,valid_replicates\n" + line + "\n")
    with pytest.raises(ValueError):
        api().verify_bootstrap_csv(
            p,
            [dict(statistic="x", point_estimate=0.05222703514631721, valid_replicates=5000)],
            abs_tol=2e-11,
        )


def test_stress_recomputation_accepts_roundoff_but_authenticates_catalog_exactly(tmp_path):
    import json

    from scripts import verify_stress_counterfactual as frozen
    from scripts.stress_counterfactual_delivery import save_tables

    saved = {"metricas": [dict(cagr="0.0522270351463172", final_equity_usdt="10000")]}
    expected = {"metricas": [dict(cagr=0.05222703514631721, final_equity_usdt="10000")]}
    save_tables(tmp_path, saved)
    assert hasattr(api(), "verify_stress_tables"), "separate persisted identity absent"
    assert api().verify_stress_tables(tmp_path, expected, frozen) == 1
    catalog = json.loads((tmp_path / "catalogo.json").read_text())
    catalog["metricas"]["semantic_sha256"] = "0" * 64
    (tmp_path / "catalogo.json").write_text(json.dumps(catalog))
    with pytest.raises(ValueError, match="catalog"):
        api().verify_stress_tables(tmp_path, expected, frozen)


def test_stress_csv_export_must_equal_persisted_parquet_exactly(tmp_path):
    from scripts import verify_stress_counterfactual as frozen
    from scripts.stress_counterfactual_delivery import save_tables

    truth = {"metricas": [dict(cagr="0.0522270351463172")]}
    save_tables(tmp_path, truth)
    path = tmp_path / "metricas.csv"
    path.write_text(path.read_text().replace("0.0522270351463172", "0.05222703514631721"))
    assert hasattr(api(), "verify_stress_tables"), "separate persisted identity absent"
    with pytest.raises(ValueError, match="CSV"):
        api().verify_stress_tables(tmp_path, truth, frozen)


def test_preflight_rejects_changed_code_before_loading_it(tmp_path):
    import hashlib
    import json

    code = tmp_path / "verifier.py"
    code.write_bytes(b'print("original")\n')
    manifest = tmp_path / "manifiesto_paquete.json"
    manifest.write_text(
        json.dumps(
            {
                "members": [
                    dict(
                        path="verifier.py",
                        bytes=code.stat().st_size,
                        sha256=hashlib.sha256(code.read_bytes()).hexdigest(),
                    )
                ]
            }
        )
    )
    pinned = hashlib.sha256(manifest.read_bytes()).hexdigest()
    (tmp_path / "manifiesto_paquete.sha256").write_text(pinned + "\n")
    assert hasattr(api(), "authenticate_package"), "trusted preflight absent"
    assert api().authenticate_package(tmp_path, pinned)["members"] == 1
    code.write_bytes(b'print("tampered")\n')
    with pytest.raises(ValueError, match="member"):
        api().authenticate_package(tmp_path, pinned)


def test_preflight_rejects_self_consistent_reseal_and_unlisted_member(tmp_path):
    import hashlib
    import json

    manifest = tmp_path / "manifiesto_paquete.json"
    manifest.write_text(json.dumps({"members": []}))
    pinned = hashlib.sha256(manifest.read_bytes()).hexdigest()
    (tmp_path / "manifiesto_paquete.sha256").write_text(pinned + "\n")
    assert hasattr(api(), "authenticate_package"), "trusted preflight absent"
    (tmp_path / "extra").write_text("added")
    with pytest.raises(ValueError, match="membership"):
        api().authenticate_package(tmp_path, pinned)
    manifest.write_text(json.dumps({"members": [], "new": "resealed"}))
    (tmp_path / "manifiesto_paquete.sha256").write_text(
        hashlib.sha256(manifest.read_bytes()).hexdigest()
    )
    with pytest.raises(ValueError, match="pinned"):
        api().authenticate_package(tmp_path, pinned)


def test_csv_schema_is_union_of_sparse_source_rows():
    actual = [
        {"symbol": "BTC", "asset_only": "1", "portfolio_only": ""},
        {"symbol": "PORTFOLIO", "asset_only": "", "portfolio_only": "2"},
    ]
    expected = [
        {"symbol": "BTC", "asset_only": "1"},
        {"symbol": "PORTFOLIO", "portfolio_only": "2"},
    ]
    api().same_rows(actual, expected, "exposicion_periodo")


def test_long_format_cagr_delta_preserves_metric_identity():
    api().same_rows(
        [
            dict(
                metric="cagr",
                value="0.0522270351463172",
                base_value="0.1",
                delta="-0.0477729648536828",
            )
        ],
        [
            dict(
                metric="cagr",
                value=0.05222703514631721,
                base_value="0.1",
                delta="-0.04777296485368279",
            )
        ],
        "deltas",
    )
    with pytest.raises(ValueError):
        api().same_rows(
            [dict(metric="net_pnl_usdt", value="1.0")],
            [dict(metric="net_pnl_usdt", value="1.0000000000000001")],
            "money",
        )


@pytest.mark.parametrize(
    "field", ["comparator_value", "general_value", "close_only_value", "close_minus_general"]
)
def test_alternate_long_cagr_columns_require_matching_metric(field):
    api().same_rows(
        [{"metric": "cagr", field: "0.0522270351463172"}],
        [{"metric": "cagr", field: 0.05222703514631721}],
        "contrasts",
    )
    with pytest.raises(ValueError):
        api().same_rows(
            [{"metric": "net_pnl_usdt", field: "1"}],
            [{"metric": "net_pnl_usdt", field: "1.0000000000000001"}],
            "money",
        )
    with pytest.raises(ValueError):
        api().same_rows(
            [{"metric": "cagr", field: "0.0522270351463172"}],
            [{"metric": "net_return", field: 0.05222703514631721}],
            "identity",
        )
