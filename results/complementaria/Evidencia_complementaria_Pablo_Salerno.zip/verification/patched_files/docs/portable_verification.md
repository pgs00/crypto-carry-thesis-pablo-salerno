# Verificación compacta portable: capa externa de comparación

Esta herramienta nueva se aplica a las distribuciones del commit
`8b395342b7e3a9dd1fbb59f72bee6b5e6efebb49`. No sustituye el antecedente de
Windows ni convierte un fallo del verificador literal original en un pase.
Los resultados se identifican como `portable_comparator_overlay_v1`.

`verify_compact_portable.py` autentica el manifiesto contra un SHA-256 anclado
para cada bloque, comprueba inventario, tamaños y hashes antes de cargar las
herramientas congeladas, y repite ese control al terminar. Los módulos
analíticos deben proceder de `herramientas` del paquete autenticado. No se
modifican snapshots, carteras, cifras, outputs financieros, manifiestos,
sidecars ni tolerancias contables. No se ejecuta el motor económico.

## Política de comparación

- CAGR: tolerancia absoluta de `16 × sys.float_info.epsilon`, aproximadamente
  `3.552713678800501e-15` en tasa, con tolerancia relativa cero. Se fija un
  presupuesto conservador de redondeo binario sobre escala unitaria, independiente
  de la diferencia concreta observada. No es una cota universal para cálculos
  mal condicionados: una diferencia mayor provoca fallo.
- Solo se aplica a `cagr`, `conditional_cagr`, `difference_cagr`, `inherited_cagr`,
  `new_cagr` y `portfolio_cagr`, o a `value`, `base_value`, `delta`, `comparator_value`, `general_value`,
  `close_only_value` y `close_minus_general` cuando
  la identidad de `metric` coincide exactamente con uno de esos campos.
  La reducción en formato largo sigue siendo una estadística CAGR, no dinero.
- El resto de campos conserva la comparación textual exacta, incluidos importes,
  IDs, fechas, conteos, estados y categorías. Se preserva el esquema de columnas
  de la tabla y el padding vacío que la exportación CSV aplica a filas heterogéneas
  de activo/cartera. Se conserva el orden de filas. NaN e infinitos no se aceptan
  como tasas numéricas.
- CSV del bootstrap: solo sus campos de tipo float se comparan con el mismo
  `SCALAR_ATOL=2e-11` que el verificador congelado ya usa para JSON y Parquet;
  el resto de campos, columnas y orden siguen siendo exactos. No se altera
  `POINT_ATOL`, el chequeo escalar/vectorizado ni la tolerancia contable de
  `1E-8` USDT.
- Estrés: el digest semántico del catálogo se contrasta exactamente contra el
  Parquet persistido; el CSV debe igualar ese Parquet exactamente. La comparación
  del recálculo usa después la política CAGR. Se distinguen identidad de los bytes
  publicados y equivalencia numérica del recálculo.

Cada diferencia textual aceptada se registra en el JSON con campo, fila, valor
publicado, valor recalculado, diferencia absoluta y tolerancia. El JSON incluye
hashes de la capa externa y del verificador congelado, entorno y resultados
originales. La salida debe ser nueva y estar fuera de todo paquete sellado.

## Ejecución en Linux

Desde la raíz de un checkout completo con el parche aplicado:

```bash
uv --cache-dir .uv-cache sync --frozen --python 3.14.3
mkdir ../auditoria_portable_nueva
.venv/bin/python -B -X utf8 scripts/verify_compact_portable.py --block B2 --package results/senal/evidencia --output ../auditoria_portable_nueva/b2.json
.venv/bin/python -B -X utf8 scripts/verify_compact_portable.py --block B3 --package results/costos_capacidad/evidencia --output ../auditoria_portable_nueva/b3.json
.venv/bin/python -B -X utf8 scripts/verify_compact_portable.py --block B4 --package results/ejecucion/evidencia --output ../auditoria_portable_nueva/b4.json
.venv/bin/python -B -X utf8 scripts/verify_compact_portable.py --block B5 --package results/estres/evidencia --output ../auditoria_portable_nueva/b5.json
.venv/bin/python -B -X utf8 scripts/verify_compact_portable.py --block B6 --package results/estabilidad/evidencia --output ../auditoria_portable_nueva/b6.json
```

BASE, riesgo, capital y SOFR conservan los comandos originales de
[reproducción](reproduction.md), usando `.venv/bin/python` en Linux. Un verificador
original fallido y el resultado de esta capa se conservan en archivos separados.

## Suite y límites del entorno

La colisión de `tests/conftest.py` y `tests/unit/conftest.py` se evita exponiendo
`warmup_factory` como fixture; la prueba deja de importar `conftest` por nombre.
No cambia el motor ni los datos sintéticos utilizados.

```bash
.venv/bin/python -B -X utf8 -m pytest tests -q -p no:cacheprovider --basetemp ../pytest_nuevo
```

La prueba histórica que clona el repositorio necesita un checkout con los objetos
Git e historia de referencia disponibles; un clone shallow/promisor puede fallar
antes de comprobar economía. Python 3.14 usa `forkserver` por defecto en este Linux;
si el entorno prohíbe crear sockets AF_UNIX, la prueba de paralelismo falla por
`PermissionError`, antes del cálculo en workers. La misma prueba puede verificarse
separadamente con el contexto portable `spawn`, sin cambiar código ni tolerancias:

```bash
.venv/bin/python -B -c "import multiprocessing,pytest; multiprocessing.set_start_method('spawn'); raise SystemExit(pytest.main(['tests/unit/test_stability_bootstrap.py::test_scalar_vectorized_and_serial_parallel_identity','-q','-p','no:cacheprovider']))"
```

Este diagnóstico separado no borra el fallo de la ejecución predeterminada. Las
pruebas omitidas por variables de paquete ausentes tampoco equivalen a pases.
