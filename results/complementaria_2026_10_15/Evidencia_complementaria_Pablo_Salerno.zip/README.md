# Evidencia complementaria de la tesina de Pablo Salerno

Revisión: 15 de octubre de 2026. Acompaña las versiones finales de la tesina y del Executive Briefing.

## Qué cambia

- H1: comparación adicional con medias de 7 y 14 días y una tasa constante; mismas 10.180 observaciones válidas. La mejora del EWMA es 27,6256% frente a la última tasa y 4,2185% frente a la media de 7 días.
- H3: oportunidad anual y mensual, conservando la prueba original entre subperíodos. No hay minutos elegibles para nuevas entradas en 2025 ni enero–agosto de 2026; esto no impide posiciones heredadas ni renovaciones.
- Basis: media, mediana y frecuencia negativa por activo, año y subperíodo en las señales válidas. Se excluye la observación BTC de 10/11/2023 16:01 UTC invalidada por controles de mercado.
- Funding: tasas observadas anualizadas con duraciones reales; son descriptores del mercado, no retornos de cartera.
- Caja: remuneración hipotética ex post de 0%, 50%, 75% y 100% del saldo contable libre a SOFR. No cambia operaciones, cantidades ni costos de BASE.
- Edición: resumen con cifras, veredictos H1/H2/H3, explicación de entrada frente a renovación, nueve ciclos cerrados, secuencia del incidente de marzo de 2023, terminología, declaración de IA y bibliografía.

Los valores base originales no se sustituyen por los escenarios complementarios. El CAGR hipotético de caja al 100% es 4,6853% frente a 3,7529%. El saldo no descuenta reservas de órdenes pendientes y no acredita dinero retirable, acceso real a SOFR ni ejecución intradiaria. Los Sharpes siguen usando tasa libre de riesgo cero.

## Reproducir cálculos

Los scripts cuantitativos requieren únicamente la biblioteca estándar de Python. Ejecutar desde la carpeta extraída:

```bash
python quant_h1/analyze_feedback.py
python cash_review/validate_cash_overlay.py
```

El primer script autentica sus insumos, reconstruye los pronósticos y genera las tablas de H1, basis y funding. El segundo comprueba las fuentes de caja, calendario y tasas SOFR, genera las sensibilidades y verifica la oportunidad de H3. Los archivos JSON de procedencia documentan los hashes Git y las rutas del commit 8b395342b7e3a9dd1fbb59f72bee6b5e6efebb49.

Para regenerar los cuatro gráficos, instalar pandas, numpy y matplotlib y ejecutar:

```bash
python build_figures.py
```

## Estructura

- `quant_h1/`: script, insumos congelados, tablas CSV y controles de pronóstico, basis y funding.
- `cash_review/`: cálculo independiente, fuentes congeladas, series diarias y sensibilidades de caja y H3.
- `figures/`: cuatro gráficos en PNG y SVG.
- `source_tables/`: patrimonio diario base para el gráfico de carteras.
- `verification/`: parche y registros de las correcciones de reproducción; consultar su guía específica.
- `document_validation.json`: comprobación de preservación de 16 tablas numéricas originales, 7 ecuaciones nativas, 38 destinos externos y 10 enlaces internos.
- `SHA256SUMS.json`: inventario del contenido de este paquete.

## Alcance

Los cálculos complementarios no constituyen una repetición integral de los backtests con todas las fuentes masivas de mercado ni una prueba fuera de muestra. Las comparaciones nuevas no heredan los intervalos de significación del bootstrap original. Los parches se entregan separados y no se han publicado en GitHub.

La declaración de IA refleja la asistencia en código, gráficos, tablas, cálculos y edición, y la responsabilidad del autor por análisis e interpretación. No se afirma que esta revisión certifique una política institucional de uso de IA; prevalece la consigna y la evaluación docente aplicable.
