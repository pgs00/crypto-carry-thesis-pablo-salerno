from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.ticker import FuncFormatter

ROOT = Path(__file__).resolve().parent
FIG = ROOT / 'figures'
FIG.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':10,
                     'axes.edgecolor':'#869299','axes.spines.top':False,
                     'axes.spines.right':False,'axes.grid':True,'grid.alpha':.18,
                     'grid.color':'#77838c','legend.frameon':False,
                     'figure.facecolor':'white','axes.facecolor':'white'})
COLORS = ['#24576D','#BC7537','#778A5C','#8C6689','#808991']

def save(fig,name):
    fig.savefig(FIG/f'{name}.png',dpi=220,bbox_inches='tight',facecolor='white')
    fig.savefig(FIG/f'{name}.svg',bbox_inches='tight',facecolor='white')
    plt.close(fig)

equity=pd.read_csv(ROOT/'source_tables/equity_diario.csv',parse_dates=['date'])
fig,ax=plt.subplots(figsize=(8.1,3.15))
for strategy,label,color in [('conditional','Condicional',COLORS[0]),('permanent','Incondicional',COLORS[1])]:
    d=equity[equity.strategy==strategy]
    ax.plot(d.date,d.equity_usdt,label=label,color=color,lw=1.7)
ax.set_ylabel('Patrimonio (USDT)');ax.xaxis.set_major_locator(mdates.YearLocator())
ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
ax.yaxis.set_major_formatter(FuncFormatter(lambda x,p:f'{x:,.0f}'.replace(',','.')))
ax.set_xlim(pd.Timestamp('2022-01-01'),pd.Timestamp('2026-09-01'))
ax.legend(loc='upper left',ncol=2)
save(fig,'equity_base')

h3=pd.read_csv(ROOT/'cash_review/h3_daily.csv',parse_dates=['date'])
monthly=h3.set_index('date').opportunity.resample('MS').mean()*10000
fig,ax=plt.subplots(figsize=(8.1,3.1))
ax.plot(monthly.index,monthly.values,color=COLORS[0],lw=1.7,marker='o',markersize=2.7)
ax.fill_between(monthly.index,monthly.values,alpha=.1,color=COLORS[0])
ax.set_ylabel('Oportunidad media (pb / 168 h)')
ax.xaxis.set_major_locator(mdates.YearLocator());ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
ax.set_xlim(pd.Timestamp('2022-01-01'),pd.Timestamp('2026-09-01'));ax.set_ylim(bottom=0)
save(fig,'h3_monthly')
print('Base equity and H3 figures built.')

h1=pd.read_csv(ROOT/'quant_h1/outputs/h1_mae_summary.csv',dtype={'period':str})
h1=h1[(h1.symbol=='EQUAL_WEIGHT') & h1.period.isin(['2022','2023','2024','2025','2026'])].copy()
fig,ax=plt.subplots(figsize=(8.1,3.5))
for k,label,color,ls in [('mae_ewma_bps','EWMA',COLORS[0],'-'),
                         ('mae_no_change_bps','Última tasa',COLORS[1],'-'),
                         ('mae_rolling_7d_bps','Media de 7 días',COLORS[2],'--'),
                         ('mae_rolling_14d_bps','Media de 14 días',COLORS[3],'--'),
                         ('mae_constant_001pct_8h_bps','Tasa constante',COLORS[4],':')]:
    ax.plot(h1.period,h1[k],label=label,color=color,lw=1.7,marker='o',markersize=3.5,linestyle=ls)
ax.set_ylabel('MAE (pb / 168 h)');ax.set_ylim(bottom=0)
ax.set_xticks(range(5),['2022','2023','2024','2025','Ene.–ago. 2026'])
ax.legend(loc='upper center',bbox_to_anchor=(.5,1.25),ncol=3,columnspacing=1.8)
save(fig,'h1_mae_year')

fund=pd.read_csv(ROOT/'quant_h1/outputs/funding_by_year.csv')
fig,ax=plt.subplots(figsize=(8.1,3.25))
import numpy as np
x=np.arange(5)
for i,(symbol,label,color) in enumerate([('BTCUSDT','BTC',COLORS[0]),('ETHUSDT','ETH',COLORS[1])]):
    d=fund[fund.symbol==symbol].sort_values('year')
    ax.bar(x+(i-.5)*.34,d.simple_annualized_funding_pct,width=.32,label=label,color=color,zorder=3)
ax.set_ylabel('Funding anualizado simple (%)')
ax.set_xticks(x,['2022','2023','2024','2025','Ene.–ago. 2026'])
ax.legend(loc='upper left',ncol=2);ax.set_ylim(bottom=0)
save(fig,'funding_year')
print('H1 and annual funding figures built.')
